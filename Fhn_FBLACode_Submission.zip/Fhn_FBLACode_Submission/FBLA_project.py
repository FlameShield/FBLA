#importing tkinter to use it's gui and abilities
import tkinter as tk
from tkinter import ttk
from tkinter import *
import time
import csv
import os
if not os.path.exists('user_account_details.csv'):
    with open('user_account_details.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['username', 'password', 'email', 'grade','points'])

def user_page_buttons(framed):
    def user_home():
        framed.destroy()
        print("Go Home")
        user_home_top()
    def user_account():
        framed.destroy()
        print("Go Account")
    def user_submit():
        framed.destroy()
        print("Go Submit")
        user_submit_top()
    def user_prizes():
        framed.destroy()
        print("Go Prizes")
    def user_tracker():
        framed.destroy()
        print("Go Tracker")
    #defines a function that adds the page buttons to the user's view
    global user_home_frame
    user_home_frame = tk.Frame(master=framed)
    user_home_frame.grid(row=0,rowspan=5,column=0,columnspan=7)
    home_select = tk.Button(master=user_home_frame,width=15,height=3,text="Home",command=user_home).grid(row=0,column=0,sticky=tk.W,pady=3,padx=5)
    account_select = tk.Button(master=user_home_frame,width=15,height=3,text="Account",command=user_account).grid(row=1,column=0,sticky=tk.W,padx=5)
    sumbit_select = tk.Button(master=user_home_frame,width=15,height=3,text="Submit",command=user_submit).grid(row=2,column=0,sticky=tk.W,padx=5)
    prizes_select = tk.Button(master=user_home_frame,width=15,height=3,text="Prizes",command=user_prizes).grid(row=3,column=0,sticky=tk.W,padx=5)
    tracker_select = tk.Button(master=user_home_frame,width=15,height=3,text="Tracker",command=user_tracker).grid(row=4,column=0,sticky=tk.W,padx=5)
        
def create_account():
    
    #The window for the creation of an account
    def get_new_info():
        def add_user(username, password):
            with open('user_account_details.csv', 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([username, password])
        #collects the username and password entered, and then deletes the into
        y = username_create_entry.get()
        y1 = password_create_entry.get()
        print(y,y1)
        add_user(y,y1)
        
        #destroys the create account window
        window_create.destroy()
        
    #setting the create accounts root and parameters
    window_create = tk.Tk()
    window_create.columnconfigure([0], minsize=250)
    window_create.rowconfigure([0, 6], minsize=100)
    
    #label for creating an account
    hello = tk.Label(master=window_create,text="Create New Account",font=("Calibri",18))
    hello.grid(row=0,column=0)
    
    #creating and placing the create accounts username and passwords label and entrys
    username_create = tk.Label(master=window_create,text="Username")
    username_create.grid(row=1,column=0)
    username_create_entry = tk.Entry(master=window_create)
    username_create_entry.grid(row=2,column=0)
    password_create = tk.Label(master=window_create,text="Password")
    password_create.grid(row=3,column=0)
    password_create_entry = tk.Entry(master=window_create)
    password_create_entry.grid(row=4,column=0)
    enter_create = tk.Button(master=window_create,text="Create",command=get_new_info)
    enter_create.grid(row=5,column=0)
    
    #starts the create accounts loop
    window_create.mainloop()
    
def login_screen():
    #login screen to define if you are an admin or a user
    def login_top_window():
        def get_login(): 
            #geting the fields text   
            x = username_entry.get()
            x1 = password_entry.get()
            if x == "" or x1 == "":
                answer = tk.Label(master=login_top,text="Missing Field(s)")
                answer.grid(row=11,column=0)
                return False
            
            def check_user_login(username, password):
                with open('user_account_details.csv', 'r') as file:
                    reader = csv.reader(file)
                    for row in reader:
                        if row[0] == username and row[1] == password:
                            print("True")
                            return True
                    print("False")
                    return False
            def check_admin_login(username, password):
                with open('admin_account_details.csv', 'r') as file:
                    reader = csv.reader(file)
                    for row in reader:
                        if row[0] == username and row[1] == password:
                            print("True")
                            return True
                    print("False")
                    return False
                
            #checks the values of x and sees if you can enter an admin or user window
            if check_user_login(x,x1) == True:
                answer = tk.Label(master=login_top,text="User Correct")
                answer.grid(row=11,column=0)
                login_top.destroy()
                window.deiconify()
                user_home_top()
            elif check_admin_login(x,x1) == True:
                answer = tk.Label(master=login_top,text="Admin Correct")
                answer.grid(row=11,column=0)
                login_top.destroy()
                window.deiconify()
                admin_home_top()
            else:
                answer = tk.Label(master=login_top,text="     Incorrect     ")
                answer.grid(row=11,column=0)
                
        def hit_enter_button(event):
            #paths the event key "Enter" to the enter button's command
            get_login()
            
        window.withdraw()
        login_top = Toplevel()
        login_top.geometry("350x300")
        #creating an event key for "Enter"
        login_top.bind('<Return>', hit_enter_button)
        
        #creating and placing the school name and software name
        school_name = tk.Label(master=login_top,text="Francis Howell North",font=("Calibri",30))
        school_name.grid(row=0,column=0)
        software = tk.Label(master=login_top,text="Shotty-Ann Software",font=("Calibri",22))
        software.grid(row=1,column=0)
        
        #creating the username and password labels, and entrys
        username_label = tk.Label(master=login_top,text="Username")
        username_label.grid(row=3,column=0)
        username_entry = tk.Entry(master=login_top)
        username_entry.grid(row=5,column=0)
        password_label = tk.Label(master=login_top,text="Password")
        password_label.grid(row=7,column=0)
        password_entry = tk.Entry(master=login_top)
        password_entry.grid(row=9,column=0)
        
        #creating the enter button to check the entered information
        enter_button = tk.Button(master=login_top,text="Enter",command=get_login)
        enter_button.grid(row=10,column=0)
        
        #creating the create account button
        create_account_button = tk.Button(master=login_top,text="Create Account",command=create_account)
        create_account_button.grid(row=12,column=0)
        login_top.mainloop()
        
    #configuring the login window's root and parameters
    window = tk.Tk()
    window.eval('tk::PlaceWindow . center')
    login_top_window()
    
    #Begins the loop to display the window
    window.mainloop()
def admin_home_top():
    admin_home_top = Toplevel()
    accounts_info = tk.Button(master=admin_home_top,text="Accounts Info").grid(row=0,column=0)
    prizes_edit = tk.Button(master=admin_home_top,text="Prizes").grid(row=0,column=1)
    submissions = tk.Button(master=admin_home_top,text="submissions").grid(row=1,column=0)
    winners = tk.Button(master=admin_home_top,text="Winners/report").grid(row=1,column=1)
    admin_home_top.mainloop()
def user_home_top():
    #creating the user's root window
    user_home_top = Toplevel()
    user_home_top.geometry("650x315")
    
    #calls the page buttons function
    user_page_buttons(user_home_top)
    
    #creating the calendar
    home_page_name = tk.Label(master=user_home_top,text="FHN EVENT SOFTWARE",font=("Times New Roman",25))
    home_page_name.grid(row=0,column=1,columnspan=9,rowspan=2)
    calendargrid1 = tk.Label(master=user_home_frame,relief="solid",text="3/20/23 6pm Men's Basketball",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid1.grid(row=2,column=1,sticky=tk.S,padx=0,pady=0)
    calendargrid2 = tk.Label(master=user_home_frame,relief="solid",text="3/21/23 No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid2.grid(row=2,column=2,sticky=tk.S,padx=0,pady=0)
    calendargrid3 = tk.Label(master=user_home_frame,relief="solid",text="3/22/23 No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid3.grid(row=2,column=3,sticky=tk.S,padx=0,pady=0)
    calendargrid4 = tk.Label(master=user_home_frame,relief="solid",text="3/23/23 No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid4.grid(row=2,column=4,sticky=tk.S,padx=0,pady=0)
    calendargrid5 = tk.Label(master=user_home_frame,relief="solid",text="3/24/23 5pm Football Game",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid5.grid(row=2,column=5,sticky=tk.S,padx=0,pady=0)
    calendargrid6 = tk.Label(master=user_home_frame,relief="solid",text="3/25/23 4:30pm Bowling League",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid6.grid(row=2,column=6,sticky=tk.S,padx=0,pady=0)
    calendargrid7 = tk.Label(master=user_home_frame,relief="solid",text="3/26/23 No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid7.grid(row=2,column=7,sticky=tk.S,padx=0,pady=0)
    calendargrid8 = tk.Label(master=user_home_frame,relief="solid",text="3/27/23 5pm Women's Basketball",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid8.grid(row=3,column=1,sticky=tk.S,padx=0,pady=0)
    calendargrid9 = tk.Label(master=user_home_frame,relief="solid",text="3/28/23 5:30pm Choir Concert",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid9.grid(row=3,column=2,sticky=tk.S,padx=0,pady=0)
    calendargrid10 = tk.Label(master=user_home_frame,relief="solid",text="3/29/23 No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid10.grid(row=3,column=3,sticky=tk.S,padx=0,pady=0)
    calendargrid11 = tk.Label(master=user_home_frame,relief="solid",text="3/30/23 5pm Women's Volleyball",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid11.grid(row=3,column=4,sticky=tk.S,padx=0,pady=0)
    calendargrid12 = tk.Label(master=user_home_frame,relief="solid",text="3/31/23 6pm Band Concert",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid12.grid(row=3,column=5,sticky=tk.S,padx=0,pady=0)
    calendargrid13 = tk.Label(master=user_home_frame,relief="solid",text="4/1/23 No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid13.grid(row=3,column=6,sticky=tk.S,padx=0,pady=0)
    calendargrid14 = tk.Label(master=user_home_frame,relief="solid",text="4/2/23 No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid14.grid(row=3,column=7,sticky=tk.S,padx=0,pady=0)
    calendargrid15 = tk.Label(master=user_home_frame,relief="solid",text="4/3/23 5pm Foortball Game",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid15.grid(row=4,column=1,sticky=tk.S,padx=0,pady=0)
    calendargrid16 = tk.Label(master=user_home_frame,relief="solid",text="4/4/23No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid16.grid(row=4,column=2,sticky=tk.S,padx=0,pady=0)
    calendargrid17 = tk.Label(master=user_home_frame,relief="solid",text="4/5/23 4:30pm Men's Basketball",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid17.grid(row=4,column=3,sticky=tk.S,padx=0,pady=0)
    calendargrid18 = tk.Label(master=user_home_frame,relief="solid",text="4/6/23 6pm Chess Tourney",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid18.grid(row=4,column=4,sticky=tk.S,padx=0,pady=0)
    calendargrid19 = tk.Label(master=user_home_frame,relief="solid",text="4/7/23 5:40pm Football Game",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid19.grid(row=4,column=5,sticky=tk.S,padx=0,pady=0)
    calendargrid20 = tk.Label(master=user_home_frame,relief="solid",text="4/8/23 No Event",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid20.grid(row=4,column=6,sticky=tk.S,padx=0,pady=0)
    calendargrid21 = tk.Label(master=user_home_frame,relief="solid",text="4/9/23 5pm Women's Basketball",wraplength=60,borderwidth=1,width=10,height=4)
    calendargrid21.grid(row=4,column=7,sticky=tk.S,padx=0,pady=0)
    
    #starts the loop for the user's window
    user_home_top.mainloop()
        
def user_submit_top():
    def get_submission():
        
        date_ent = event_date_submit.get()
        print(event_date_get,date_ent)
    user_submit_top = Toplevel()
    user_submit_top.geometry("650x315")
    user_page_buttons(user_submit_top)
    submit_photo = tk.Label(master=user_home_frame,relief="solid",text="Submit Photo",width=45,height=20)
    submit_photo.grid(row=0,rowspan=5,column=2,columnspan=5)
    
    submit_drop_var = ttk.Combobox(user_submit_top, values=["Football","Basketball","Vollyball","Choir","Band","Chess","Swimming"])
    submit_drop_var.grid(row=1,column=6,sticky=tk.E)
    def on_select(event):
        global event_date_get
        event_date_get = event.widget.get()

    # Bind the function to the ComboboxSelected event
    submit_drop_var.bind("<<ComboboxSelected>>", on_select)
    
    event_date_label = tk.Label(master=user_home_frame,text="Date of Event")
    event_date_label.grid(row=2,column=12)
    event_date_entry = tk.Entry(master=user_home_frame)
    event_date_entry.grid(row=3,column=12)
    event_date_submit = tk.Button(master=user_home_frame,text="Submit",command=get_submission)
    event_date_submit.grid(row=4,column=12)
    
    user_submit_top.mainloop()

#begins the program from the loging screen
login_screen()